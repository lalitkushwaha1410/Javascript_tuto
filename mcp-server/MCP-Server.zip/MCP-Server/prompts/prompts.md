prompt - 1 : Using instructions as per mcp.Jira.instructions.md file, analyse the requirement from the JIRA ticket and execute the same.

prompt - 2 : Use the instructions as per mcp.Tasklist.instructions.md file and write only the scenerios for tasklist application to the excel.

prompt - 3 : use instructions as per mcp.instructions.md file and execute all scenarios one by one and write the status in excel.